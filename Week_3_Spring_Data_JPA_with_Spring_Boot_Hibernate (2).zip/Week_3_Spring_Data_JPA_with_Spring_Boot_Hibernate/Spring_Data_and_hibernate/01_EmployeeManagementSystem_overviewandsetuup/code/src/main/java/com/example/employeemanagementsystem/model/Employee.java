package com.example.employeemanagementsystem.model;

public class Employee {

}
