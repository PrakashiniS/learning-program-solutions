package com.example.employeemanagementsystem.repository;

public class DepartmentRepository {

}
