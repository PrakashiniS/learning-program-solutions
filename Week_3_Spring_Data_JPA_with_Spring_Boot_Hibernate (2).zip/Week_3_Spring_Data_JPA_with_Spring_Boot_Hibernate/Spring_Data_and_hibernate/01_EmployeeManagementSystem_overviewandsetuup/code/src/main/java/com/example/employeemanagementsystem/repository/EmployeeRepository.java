package com.example.employeemanagementsystem.repository;

public class EmployeeRepository {

}
